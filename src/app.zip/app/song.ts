export class Song {
    name: string;
    artist: string;
    id: string;
}
