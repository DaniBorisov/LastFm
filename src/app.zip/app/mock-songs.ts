// import { Song } from './song';

// export const Songs: Song[] = [
//   { id: 1, name: 'Mr. Nice', artist: 'dada' },
//   { id: 2, name: 'Narco', artist: 'dada'  },
//   { id: 3, name: 'Bombasto', artist: 'dada'  },
//   { id: 4, name: 'Celeritas', artist: 'dada'  },
//   { id: 5, name: 'Magneta', artist: 'dada'  }

// ];
